const statusCheck = [
    {
        type: "hold",
        style: `bg-red-500 text-white p-2 rounded capitalize`,
    },
    {
        type: "active",
        style: `bg-primary text-white p-2 rounded capitalize`,
    },
];

export { statusCheck };
