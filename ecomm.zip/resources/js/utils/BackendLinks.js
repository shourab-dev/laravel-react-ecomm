const backendLinks = [
    {
        id: 1,
        label: "Dashboard",
        url: "dashboard",
    },
    {
        id: 2,
        label: "Category",
        url: "admin.category.index",
    },
    {
        id: 3,
        label: "Products",
        url: "admin.products.all",
    },
];

export { backendLinks };
