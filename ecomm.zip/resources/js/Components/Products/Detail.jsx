import React from "react";

const Detail = ({ data }) => {
    return <>{data}</>;
};

export default Detail;
