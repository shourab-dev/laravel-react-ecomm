import Frontend from '@/Layouts/Frontend'
import React from 'react'

const ArcheivePage = () => {

    

  return (
    <div>ArcheivePage </div>
  )
}

ArcheivePage.layout = (page) => <Frontend children={page} pageTitle='Category Archeive Page' />


export default ArcheivePage